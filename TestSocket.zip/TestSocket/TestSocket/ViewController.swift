//
//  ViewController.swift
//  TestSocket
//
//  Created by Dung Nguyen on 12/31/15.
//  Copyright © 2015 Dung Nguyen. All rights reserved.
//

import UIKit
class ViewController: UIViewController,NSStreamDelegate {

    private let serverAddress: CFString = "127.0.0.1"
    private let serverPort: UInt32 = 1234
    private var inputStream: NSInputStream!
    private var outputStream: NSOutputStream!
    private var readStream  : Unmanaged<CFReadStream>?
    private var writeStream : Unmanaged<CFWriteStream>?

    
    var isConnection : Bool = false
    var isDisconection : Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initNetworkCommunication()
        
        let btn = UIButton(frame: CGRectMake(20,50,100,35))
        btn.layer.cornerRadius = 5.0
        btn.layer.borderWidth = 1.0
        btn.layer.borderColor = UIColor.purpleColor().CGColor
        btn.setTitleColor(UIColor.purpleColor(), forState: UIControlState.Normal)
        btn.setTitle("Send", forState: UIControlState.Normal)
        btn.addTarget(self, action: Selector("onMessage"), forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(btn)
        //self.setupSocket()
    }
    
    
    
    
    
    func onSend(){
        
        if let dataPing = "Ping\n".dataUsingEncoding(NSUTF8StringEncoding){
            outputStream?.write(UnsafePointer<UInt8>(dataPing.bytes), maxLength: dataPing.length)
            //self.socket.writeData(dataPing, withTimeout: -1, tag: 0)
        }
    }
    func onMessage(){
        if let dataPing = "Hello All\n".dataUsingEncoding(NSUTF8StringEncoding){
            outputStream?.write(UnsafePointer<UInt8>(dataPing.bytes), maxLength: dataPing.length)
        }
    }
    
    
    
    func initNetworkCommunication(){
        
        CFStreamCreatePairWithSocketToHost(nil, self.serverAddress, self.serverPort, &readStream, &writeStream)
        
        self.inputStream = readStream!.takeRetainedValue()
        self.outputStream = writeStream!.takeRetainedValue()
        
        self.inputStream.delegate = self
        self.outputStream.delegate = self
        
        self.inputStream.scheduleInRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
        self.outputStream.scheduleInRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
        
        self.inputStream.open()
        self.outputStream.open()
        

    }
    
    func pingServer(){
        if let dataPing = "Ping\n".dataUsingEncoding(NSUTF8StringEncoding){
            outputStream?.write(UnsafePointer<UInt8>(dataPing.bytes), maxLength: dataPing.length)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func disconnect(){
        if(self.isConnection){
            dispatch_async(dispatch_get_main_queue(), {[weak self] () -> Void in
                self?.outputStream!.close()
                self?.outputStream!.removeFromRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
                self?.outputStream.delegate = nil
                self?.outputStream = nil
                self?.inputStream.close()
                self?.inputStream.removeFromRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
                self?.inputStream.delegate = nil
                self?.inputStream = nil
                self?.isConnection = false
                });
        }
        else{
            initNetworkCommunication()
        }
    }
    
    func stream(aStream: NSStream, handleEvent eventCode: NSStreamEvent) {
        
        switch eventCode{
        case NSStreamEvent.OpenCompleted:
            self.isConnection = true
            break
        case NSStreamEvent.HasSpaceAvailable:
            break
        case NSStreamEvent.HasBytesAvailable:
            if aStream == inputStream{
                var buffer: UInt8 = 0
                var len: Int!
                
                while (inputStream?.hasBytesAvailable == true){
                    len = inputStream?.read(&buffer, maxLength: 2048*10)
                    if len > 0{
                        let output = NSString(bytes: &buffer, length: len, encoding: NSUTF8StringEncoding)
                        if nil != output{
                            print(output!)
                            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                                //self.onMessage()
                            });
                            //
                        }
                    }
                }
                
            }
            break
        case NSStreamEvent.ErrorOccurred:
            self.disconnect()
            break
        case NSStreamEvent.EndEncountered:
            self.disconnect()
            break
        default:
            print("Unknown event")
        }
    }

}

