//
//  ViewController.swift
//  TestSocket
//
//  Created by Dung Nguyen on 12/31/15.
//  Copyright © 2015 Dung Nguyen. All rights reserved.
//

import UIKit
class ViewController: UIViewController,NSStreamDelegate,GCDAsyncSocketDelegate {

    private let serverAddress: CFString = "127.0.0.1"
    private let serverPort: UInt32 = 1234
    private var inputStream: NSInputStream!
    private var outputStream: NSOutputStream!
    
    
    var socket : GCDAsyncSocket!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //initNetworkCommunication()
        
        let btn = UIButton(frame: CGRectMake(20,50,100,35))
        btn.layer.cornerRadius = 5.0
        btn.layer.borderWidth = 1.0
        btn.layer.borderColor = UIColor.purpleColor().CGColor
        btn.setTitleColor(UIColor.purpleColor(), forState: UIControlState.Normal)
        btn.setTitle("Send", forState: UIControlState.Normal)
        btn.addTarget(self, action: Selector("onSend"), forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(btn)
        self.setupSocket()
    }
    func setupSocket(){
        do{
            socket = GCDAsyncSocket(delegate: self, delegateQueue: dispatch_get_main_queue())
            try socket.connectToHost("localhost", onPort: 1234)
            socket.readDataWithTimeout(-1, tag: 0)
        }catch{
            print("Error Conect Socket")
        }
        
    }
    
    func socket(sock: GCDAsyncSocket!, didConnectToHost host: String!, port: UInt16) {
        print("didConnectToHost")
        // send message
        
        sock.writeData("Server Nhận Dc File Chưa\n".dataUsingEncoding(NSUTF8StringEncoding), withTimeout: -1, tag: 0)
    }
    func socketDidCloseReadStream(sock: GCDAsyncSocket!) {
        print("socketDidCloseReadStream")
    }
    func socketDidDisconnect(sock: GCDAsyncSocket!, withError err: NSError!) {
        print("socketDidDisconnect")
    }
    func socket(sock: GCDAsyncSocket!, didReadData data: NSData!, withTag tag: Int) {
        print("didReadData")
        print(NSString(data: data, encoding: NSUTF8StringEncoding))
        
    }
    func socket(sock: GCDAsyncSocket!, didReadPartialDataOfLength partialLength: UInt, tag: Int) {
        print("didReadPartialDataOfLength \(partialLength)")
    }
    func socket(sock: GCDAsyncSocket!, shouldTimeoutReadWithTag tag: Int, elapsed: NSTimeInterval, bytesDone length: UInt) -> NSTimeInterval {
        print("shouldTimeoutReadWithTag")
        return 0
    }
    func socketDidSecure(sock: GCDAsyncSocket!) {
        print("socketDidSecure")
    }
    
    
    
    
    func onSend(){
        
        if let dataPing = "Ping\n".dataUsingEncoding(NSUTF8StringEncoding){
            //outputStream?.write(UnsafePointer<UInt8>(dataPing.bytes), maxLength: dataPing.length)
            self.socket.writeData(dataPing, withTimeout: -1, tag: 0)
        }
    }
    
    
    
    func initNetworkCommunication(){
        
        var readStream: Unmanaged<CFReadStream>?
        var writeStream: Unmanaged<CFWriteStream>?
        
        CFStreamCreatePairWithSocketToHost(nil, self.serverAddress, self.serverPort, &readStream, &writeStream)
        
        self.inputStream = readStream!.takeRetainedValue()
        self.outputStream = writeStream!.takeRetainedValue()
        
        self.inputStream.delegate = self
        self.outputStream.delegate = self
        
        self.inputStream.scheduleInRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
        self.outputStream.scheduleInRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
        
        self.inputStream.open()
        self.outputStream.open()
        
    }
    
    func pingServer(){
        if let dataPing = "Ping\n".dataUsingEncoding(NSUTF8StringEncoding){
            outputStream?.write(UnsafePointer<UInt8>(dataPing.bytes), maxLength: dataPing.length)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func stream(aStream: NSStream, handleEvent eventCode: NSStreamEvent) {
        
        switch eventCode{
        case NSStreamEvent.OpenCompleted:
            break
        case NSStreamEvent.HasSpaceAvailable:
            break
        case NSStreamEvent.HasBytesAvailable:
            if aStream == inputStream{
                var buffer: UInt8 = 0
                var len: Int!
                
                while (inputStream?.hasBytesAvailable ?? false == true){
                    len = inputStream?.read(&buffer, maxLength: 1024)
                    if len > 0{
                        let output = NSString(bytes: &buffer, length: len, encoding: NSUTF8StringEncoding)
                        if nil != output{
                            print(output!)
                            self.onSend()
                        }
                    }
                }
                
            }
            break
        case NSStreamEvent.ErrorOccurred:
            break
        case NSStreamEvent.EndEncountered:
            outputStream!.close()
            outputStream!.removeFromRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
            outputStream = nil
            break
        default:
            print("Unknown event")
        }
    }

}

